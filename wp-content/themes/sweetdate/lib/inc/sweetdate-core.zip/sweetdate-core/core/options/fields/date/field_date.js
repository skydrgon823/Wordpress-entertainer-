/*global jQuery, document*/
jQuery(document).ready(function () {
    /*
     *
     * Kleo_Options_date function
     * Adds datepicker js
     *
     */
    jQuery('.squeen-opts-datepicker').datepicker();
});
